To install the theme please follow the instructions below:

1. Whithin the template archive you will find the folder named after theme name. Usually it is "theme###", where "###" is the actual number of the theme. Copy the folders "\app" and "\skin" from the theme folder into the magento root directory. You will get a prompt to replace the folder conten. Agree.

2. Open the admin panel and choose "System" -> "Design".

3. Press "Add design change" button.

4. In the new dialogue window change the "custom design" value to our theme name value.

5. Press "Save" button.

if you want to set up the sample data that is provided with the template you have to import the xxxx.sql file that contains the sample data into your magento database using phpMyAdmin or any other database management tool, copy content from media folder from the template to your magento installation and reinstall the engine.


If this instruction doesn't help, please, view the video-tutorial by this link:

http://info.template-help.com/files/Magento/how_to_install_magento_theme.htm



Other Helpful links:

Engine vendor: http://www.magentocommerce.com/
Magento user's guide: http://www.magentocommerce.com/support/magento_user_guide
Magento support: http://www.magentocommerce.com/support/overview
Magento screencasts: http://www.magentocommerce.com/media/screencasts 
